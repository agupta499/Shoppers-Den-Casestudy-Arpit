package com.shopden.dao;

import com.shopden.helpers.PostgresConnHelper;
import com.shopden.models.CartProducts;
import com.shopden.models.Order;
import com.shopden.models.PaymentMode;
import com.shopden.models.User;
import org.checkerframework.checker.units.qual.C;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class OrderImpl implements OrderDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement aorder,canorder,confirmord,selorderbyid,selorderbyuid;
    private Statement statement;
    private ResultSet resultSet;

    public OrderImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void placeOrder(User user, Order order) throws SQLException {
        String addorder=resourceBundle.getString("addorder");
        aorder=conn.prepareStatement(addorder);
        aorder.setInt(1,order.getOrderId());
        aorder.setDate(2, Date.valueOf(order.getDatePlaced()));
        aorder.setInt(3,order.getCart().getCartId());
        aorder.setInt(4,user.getUserId());
//        aorder.setDate(5, Date.valueOf(order.getDateDelivered()));
        aorder.setInt(5,order.getAmount());
//        if(order.getPaymentMode().equals(PaymentMode.DEBIT)){
//            aorder.setString(7,"Debit");
//        } else if(order.getPaymentMode().equals(PaymentMode.CREDIT)){
//            aorder.setString(7,"Credit");
//        } else if(order.getPaymentMode().equals(PaymentMode.UPI)){
//            aorder.setString(7,"UPI");
//        } else{
//            aorder.setString(7,"COD");
//        }
        aorder.setBoolean(6,order.isPaid());
        aorder.executeUpdate();
    }

    @Override
    public void confirmOrder(User user, int OrderId, String mode) throws SQLException {
        String confirmOrder = resourceBundle.getString("confirmorder");
        confirmord = conn.prepareStatement(confirmOrder);
        confirmord.setDate(1,Date.valueOf(LocalDate.now().plus(2+new Random().nextInt(5), ChronoUnit.DAYS)));
        confirmord.setString(2,mode);
        confirmord.setBoolean(3,true);
        confirmord.setInt(4, OrderId);
        confirmord.executeUpdate();

        CartProductsDao cartProductsDao = new CartProductsImpl();
        cartProductsDao.emptyUserCart(user);
    }

    @Override
    public void cancelOrder(int orderId) throws SQLException {
        String query = resourceBundle.getString("cancelorder");
        canorder = conn.prepareStatement(query);
        canorder.setInt(1,orderId);
        canorder.executeUpdate();
    }

    @Override
    public List<Order> viewAllOrder(int userId) throws SQLException {
        CartDao cartDao = new CartImpl();
        UserDao userDao = new UserImpl();
        List<Order> orderList = new ArrayList<Order>();
        Order order = null;
        String mode = null;
        String query = resourceBundle.getString("selectallorderbyuid");
        selorderbyuid = conn.prepareStatement(query);
        selorderbyuid.setInt(1,userId);
        resultSet = selorderbyuid.executeQuery();
        while(resultSet.next()){
            order = new Order();
            order.setOrderId(resultSet.getInt(1));
            order.setDatePlaced(resultSet.getDate(2).toLocalDate());
            order.setCart(cartDao.getCartById(resultSet.getInt(3)));
            order.setUser(userDao.getUserById(resultSet.getInt(4)));
            order.setDateDelivered(resultSet.getDate(5).toLocalDate());
            order.setAmount(resultSet.getInt(6));
            mode = resultSet.getString(7);
            if(mode.equals("Debit")) {
                order.setPaymentMode(PaymentMode.DEBIT);
            } else if(mode.equals("Credit")){
                order.setPaymentMode(PaymentMode.CREDIT);
            } else if(mode.equals("UPI")){
                order.setPaymentMode(PaymentMode.UPI);
            } else {
                order.setPaymentMode(PaymentMode.COD);
            }
            order.setPaid(resultSet.getBoolean(8));
            orderList.add(order);
        }
        return orderList;
    }

    @Override
    public Order getOrderById(int orderId) throws SQLException {
        CartDao cartDao = new CartImpl();
        UserDao userDao = new UserImpl();
        String query = resourceBundle.getString("selectorderbyid");
        String mode = null;
        Order order=null;
        selorderbyid = conn.prepareStatement(query);
        selorderbyid.setInt(1,orderId);
        resultSet = selorderbyid.executeQuery();
        while(resultSet.next()) {
            order=new Order();
            order.setOrderId(resultSet.getInt(1));
            order.setDatePlaced(resultSet.getDate(2).toLocalDate());
            order.setCart(cartDao.getCartById(resultSet.getInt(3)));
            order.setUser(userDao.getUserById(resultSet.getInt(4)));
            if(resultSet.getDate(5)!=null)
                order.setDateDelivered(resultSet.getDate(5).toLocalDate());
            order.setAmount(resultSet.getInt(6));
            mode = resultSet.getString(7);
            if (mode==null){
                order.setPaymentMode(null);
            } else if(mode.equals("Debit")) {
                order.setPaymentMode(PaymentMode.DEBIT);
            } else if(mode.equals("Credit")){
                order.setPaymentMode(PaymentMode.CREDIT);
            } else if(mode.equals("UPI")){
                order.setPaymentMode(PaymentMode.UPI);
            } else {
                order.setPaymentMode(PaymentMode.COD);
            }
            order.setPaid(resultSet.getBoolean(8));
        }
        return order;
    }
}
