package com.shopden.dao;

import com.shopden.helpers.PostgresConnHelper;
import com.shopden.models.Cart;
import com.shopden.models.User;
import com.shopden.models.UserRole;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class UserImpl implements UserDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement addu,deleteu,updateun,updatepass,deletecart
            ,updateaddr,updatephone,selectuid,acart,selcartbyuid;
    private Statement statement;
    private ResultSet resultSet, resultSet2;

    public UserImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public List<User> getAllUsers() throws SQLException {
        List<User>userList=new ArrayList<User>();
        User user = null;
        String query = resourceBundle.getString("selectalluser");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()) {
            user = new User();
            user.setUserId(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setSecQue(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            user.setAddress(resultSet.getString(7));
            user.setPhone(resultSet.getLong(8));
            if(resultSet.getInt(9)==1) {
                user.setUserRole(UserRole.ADMIN);
            } else {
                user.setUserRole(UserRole.CUSTOMER);
            }

            CartDao cartDao = new CartImpl();
            user.setCart(cartDao.getCartByUser(user));
            userList.add(user);
        }
        return userList;
    }

    @Override
    public void addUser(User user) throws SQLException {
        String adduser=resourceBundle.getString("adduser");
        addu=conn.prepareStatement(adduser);
        addu.setInt(1,user.getUserId());
        addu.setString(2,user.getUserName());
        addu.setString(3,user.getEmail());
        addu.setString(4,user.getPassword());
        addu.setString(5,user.getSecQue());
        addu.setString(6,user.getAnswer());
        addu.setString(7,user.getAddress());
        addu.setLong(8,user.getPhone());
        if(user.getUserRole().equals(UserRole.ADMIN)) {
            addu.setInt(9,1);
        } else {
            addu.setInt(9,2);
        }
        addu.executeUpdate();
        CartDao cartDao = new CartImpl();
        cartDao.addCart(user);
    }

    @Override
    public void updateUserName(int userId, String name) throws SQLException {
        String query = resourceBundle.getString("updateusername");
        updateun = conn.prepareStatement(query);
        updateun.setString(1,name);
        updateun.setInt(2,userId);
        updateun.executeUpdate();
    }

    @Override
    public void updateUserPass(int userId, String pass) throws SQLException {
        String query = resourceBundle.getString("updateuserpass");
        updatepass = conn.prepareStatement(query);
        updatepass.setString(1,pass);
        updatepass.setInt(2,userId);
        updatepass.executeUpdate();
    }

    @Override
    public void updateUserAddress(int userId, String add) throws SQLException {
        String query = resourceBundle.getString("updateuseraddress");
        updateaddr = conn.prepareStatement(query);
        updateaddr.setString(1,add);
        updateaddr.setInt(2,userId);
        updateaddr.executeUpdate();
    }

    @Override
    public void updateUserPhone(int userId, long phone) throws SQLException {
        String query = resourceBundle.getString("updateuserphone");
        updatephone = conn.prepareStatement(query);
        updatephone.setLong(1,phone);
        updatephone.setInt(2,userId);
        updatephone.executeUpdate();
    }

    @Override
    public void deleteUser(int userId) throws SQLException {
        CartDao cartDao = new CartImpl();
        cartDao.deleteCartByUid(userId);
        String query = resourceBundle.getString("deleteuser");
        deleteu = conn.prepareStatement(query);
        deleteu.setInt(1,userId);
        deleteu.executeUpdate();
    }

    @Override
    public User getUserById(int userId) throws SQLException {
        User user = null;
        String query = resourceBundle.getString("selectuserbyid");
        selectuid = conn.prepareStatement(query);
        selectuid.setInt(1,userId);
        resultSet=selectuid.executeQuery();
        while(resultSet.next()) {
            user = new User();
            user.setUserId(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setSecQue(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            user.setAddress(resultSet.getString(7));
            user.setPhone(resultSet.getLong(8));
            if(resultSet.getInt(9)==1) {
                user.setUserRole(UserRole.ADMIN);
            } else {
                user.setUserRole(UserRole.CUSTOMER);
            }
            CartDao cartDao = new CartImpl();
            user.setCart(cartDao.getCartByUser(user));
        }
        return user;
    }
}
