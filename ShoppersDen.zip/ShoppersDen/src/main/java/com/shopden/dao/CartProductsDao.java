package com.shopden.dao;

import com.shopden.models.CartProducts;
import com.shopden.models.Product;
import com.shopden.models.User;

import java.sql.SQLException;
import java.util.List;

public interface CartProductsDao {
    public void addProductInCart(User user, int productId, int quantity) throws SQLException;
    public void deleteProductInCart(User user, int productId) throws SQLException;
    public void updateQuantityInCart(User user, int productId, int quantity) throws SQLException;
    public List<CartProducts> getAllProductInCart(User user) throws SQLException;
    public void emptyUserCart(User user) throws SQLException;
}
