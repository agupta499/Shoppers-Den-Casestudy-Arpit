package com.shopden.dao;

import com.shopden.helpers.PostgresConnHelper;
import com.shopden.models.Cart;
import com.shopden.models.User;

import java.sql.*;
import java.util.ResourceBundle;

public class CartImpl implements CartDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement acart,selcartbyuid,deletecart,selcartbycartid;
    private Statement statement;
    private ResultSet resultSet;

    public CartImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public void addCart(User user) throws SQLException {
        String addcart=resourceBundle.getString("addcart");
        acart = conn.prepareStatement(addcart);
        acart.setInt(1,user.getCart().getCartId());
        acart.setInt(2,user.getUserId());
        acart.executeUpdate();
    }

    @Override
    public void deleteCartByUid(int uid) throws SQLException {
        String query = resourceBundle.getString("deletecartbyuid");
        deletecart = conn.prepareStatement(query);
        deletecart.setInt(1,uid);
        deletecart.executeUpdate();
    }

    @Override
    public Cart getCartByUser(User user) throws SQLException {
        int uid = user.getUserId();
        String query = resourceBundle.getString("selectcartbyuid");
        selcartbyuid=conn.prepareStatement(query);
        selcartbyuid.setInt(1,uid);
        resultSet=selcartbyuid.executeQuery();
        Cart cart = new Cart();
        while (resultSet.next()) {
            cart.setCartId(resultSet.getInt(1));
            cart.setUser(user);
        }
        return cart;
    }

    @Override
    public Cart getCartById(int cartId) throws SQLException {
        Cart cart = null;
        UserDao userDao = new UserImpl();
        String query = resourceBundle.getString("selectcartbycartid");
        selcartbycartid=conn.prepareStatement(query);
        selcartbycartid.setInt(1,cartId);
        resultSet=selcartbycartid.executeQuery();
        while (resultSet.next()) {
            cart = new Cart();
            cart.setCartId(resultSet.getInt(1));
            cart.setUser(userDao.getUserById(resultSet.getInt(2)));
        }
        return cart;
    }
}
