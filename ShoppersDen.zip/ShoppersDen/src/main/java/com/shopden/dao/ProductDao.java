package com.shopden.dao;

import com.shopden.models.Product;

import java.sql.SQLException;
import java.util.List;

public interface ProductDao {
    List<Product> getAllProducts() throws SQLException;
    public Product getProductById(int pid) throws SQLException;
    public void addProduct(Product product) throws SQLException;
    public void updateProductName(int pid,String pname) throws SQLException;
    public void updateProductQuantity(int pid,int quan) throws SQLException;
    public void updateProductPrice(int pid,int price) throws SQLException;
    public void updateProductDescription(int pid,String desc) throws SQLException;
    public void deleteProduct(int pid) throws SQLException;
}
