package com.shopden.dao;

import com.shopden.helpers.PostgresConnHelper;
import com.shopden.models.Category;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CategoryImpl implements CategoryDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement addc,selcbyid,updatec,deletec;
    private Statement statement;
    private ResultSet resultSet;

    public CategoryImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addCategory(Category category) throws SQLException {
        String addCategory = resourceBundle.getString("addcategory");
        addc = conn.prepareStatement(addCategory);
        addc.setInt(1, category.getCid());
        addc.setString(2, category.getCname());
        addc.executeUpdate();
    }

    @Override
    public List<Category> getAllCategories() throws SQLException {
        String query=resourceBundle.getString("selectallcategory");;
        List<Category> categoryList=new ArrayList<Category>();
        Category category=null;
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()){
            category=new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
            categoryList.add(category);
        }
        return categoryList;
    }

    @Override
    public Category getCategoryById(int categoryId) throws SQLException {
        Category category = null;
        String query = resourceBundle.getString("selectcategorybyid");
        selcbyid = conn.prepareStatement(query);
        selcbyid.setInt(1,categoryId);
        resultSet=selcbyid.executeQuery();
        while(resultSet.next()) {
            category = new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
        }
        return category;
    }

    @Override
    public void updateCategory(int cid, String catname) throws SQLException {
        String query = resourceBundle.getString("updatecategory");
        updatec = conn.prepareStatement(query);
        updatec.setString(1,catname);
        updatec.setInt(2,cid);
        updatec.executeUpdate();
    }

    @Override
    public void deleteCategory(int cid) throws SQLException {
        String query = resourceBundle.getString("deletecategory");
        deletec = conn.prepareStatement(query);
        deletec.setInt(1,cid);
        deletec.executeUpdate();
    }
}
