package com.shopden.dao;

import com.shopden.models.Order;
import com.shopden.models.User;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public interface OrderDao {
    void placeOrder(User user, Order order) throws SQLException;
    void confirmOrder(User user, int orderId, String mode) throws SQLException;
    void cancelOrder(int orderId) throws SQLException;
    List<Order> viewAllOrder(int userId) throws SQLException;
    Order getOrderById(int orderId) throws SQLException;
}
