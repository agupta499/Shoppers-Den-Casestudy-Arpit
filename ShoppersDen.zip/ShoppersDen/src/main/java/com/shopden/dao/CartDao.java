package com.shopden.dao;

import com.shopden.models.Cart;
import com.shopden.models.User;

import java.sql.SQLException;

public interface CartDao {
    public void addCart(User user) throws SQLException;
    public void deleteCartByUid(int uid) throws SQLException;
    public Cart getCartByUser(User user) throws SQLException;
    public Cart getCartById(int cartId) throws SQLException;
}
