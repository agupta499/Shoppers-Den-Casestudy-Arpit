package com.shopden.dao;

import com.shopden.helpers.PostgresConnHelper;
import com.shopden.models.User;

import java.sql.*;
import java.util.ResourceBundle;

public class LoginImpl implements LoginDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement validuid, validpass, validadmin;
    private Statement statement;
    private ResultSet resultSet;

    public LoginImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public boolean validateUserId(int id) throws SQLException {
        String query = resourceBundle.getString("validateuserid");
        validuid = conn.prepareStatement(query);
        validuid.setInt(1,id);
        resultSet = validuid.executeQuery();
        if(resultSet.next()){
            return true;
        }
        return false;
    }

    @Override
    public boolean validatePassword(int id, String pass) throws SQLException {
        String query = resourceBundle.getString("validatepassword");
        validpass = conn.prepareStatement(query);
        validpass.setInt(1,id);
        resultSet = validpass.executeQuery();
        if (resultSet.next() && resultSet.getString(1).equals(pass)){
            return true;
        }
        return false;
    }

    @Override
    public boolean validateAdminAccess(int id) throws SQLException {
        String query = resourceBundle.getString("validateadmin");
        validadmin = conn.prepareStatement(query);
        validadmin.setInt(1,id);
        resultSet = validadmin.executeQuery();
        if(resultSet.next()){
            if (resultSet.getInt(1)==1){
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}
