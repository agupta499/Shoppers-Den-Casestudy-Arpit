package com.shopden.dao;

import com.shopden.helpers.PostgresConnHelper;
import com.shopden.models.CartProducts;
import com.shopden.models.Product;
import com.shopden.models.User;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CartProductsImpl implements CartProductsDao {
    private ResourceBundle resourceBundle;
    private Connection conn;
    private PreparedStatement addpinc,delpinc,updqinc,selallpinc,emptycart;
    private Statement statement;
    private ResultSet resultSet;

    public CartProductsImpl() {
        conn= PostgresConnHelper.getConnection();
        if(conn==null) {
            System.out.println("Connection has issue!");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }

    @Override
    public void addProductInCart(User user, int productId, int quantity) throws SQLException {
        String addPInC=resourceBundle.getString("addproductincart");
        addpinc=conn.prepareStatement(addPInC);
        addpinc.setInt(1,user.getCart().getCartId());
        addpinc.setInt(2,productId);
        addpinc.setDate(3,Date.valueOf(LocalDate.now()));
        addpinc.setInt(4,quantity);
        addpinc.executeUpdate();
    }

    @Override
    public void deleteProductInCart(User user, int productId) throws SQLException {
        String deletePInC=resourceBundle.getString("deleteproductincart");
        delpinc=conn.prepareStatement(deletePInC);
        delpinc.setInt(1,user.getCart().getCartId());
        delpinc.setInt(2,productId);
        delpinc.executeUpdate();
    }

    @Override
    public void updateQuantityInCart(User user, int productId, int quantity) throws SQLException {
        String updateQInC=resourceBundle.getString("updatequantityincart");
        updqinc=conn.prepareStatement(updateQInC);
        updqinc.setInt(1,quantity);
        updqinc.setInt(2,user.getCart().getCartId());
        updqinc.setInt(3,productId);
        updqinc.executeUpdate();
    }

    @Override
    public List<CartProducts> getAllProductInCart(User user) throws SQLException {
        List<CartProducts> cartProductsList=new ArrayList<CartProducts>();
        Product product=null;
        CartProducts cartProducts=null;
        ProductDao productDao=new ProductImpl();
        String getAllPInC=resourceBundle.getString("selectproductincart");
        selallpinc=conn.prepareStatement(getAllPInC);
        selallpinc.setInt(1,user.getCart().getCartId());
        resultSet=selallpinc.executeQuery();
        while (resultSet.next()) {
            product=productDao.getProductById(resultSet.getInt(2));
//            System.out.println(product.getPid()
//                    +" "+product.getPname()
//                    +" "+product.getPrice()
//                    +" "+product.getCategory().getCname()
//                    +" "+resultSet.getDate(3)
//                    +" "+resultSet.getInt(4));
            cartProducts=new CartProducts();
            cartProducts.setCart(user.getCart());
            cartProducts.setProduct(product);
            cartProducts.setDateAdded(resultSet.getDate(3).toLocalDate());
            cartProducts.setQuantity(resultSet.getInt(4));
            cartProductsList.add(cartProducts);
        }
        return cartProductsList;
    }

    @Override
    public void emptyUserCart(User user) throws SQLException {
        String query = resourceBundle.getString("emptycartproducts");
        emptycart=conn.prepareStatement(query);
        emptycart.setInt(1,user.getCart().getCartId());
        emptycart.executeUpdate();
    }
}
