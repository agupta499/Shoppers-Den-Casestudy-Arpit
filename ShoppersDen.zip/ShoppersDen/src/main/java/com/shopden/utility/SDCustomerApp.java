package com.shopden.utility;

import com.shopden.dao.*;
import com.shopden.models.*;

import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class SDCustomerApp {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        UserDao userDao = new UserImpl();   // For User Methods
        ProductDao productDao = new ProductImpl();  // For Product Methods
        CartProductsDao cartProductsDao = new CartProductsImpl();   // For CartProducts Methods
        OrderDao orderDao = new OrderImpl();    // For Order Methods
        LoginDao loginDao = new LoginImpl();    // For Login Methods

        User user = null;

        top: while (true) {

            homepage:
            while (true) {
                System.out.println();
                System.out.println("============================");
                System.out.println("  Welcome to Shoppers Den!  ");
                System.out.println("============================");
                System.out.println();
                System.out.println("1. Login");
                System.out.println("2. Register");
                System.out.println("3. Exit");
                System.out.print("Enter Choice: ");
                int input = Integer.parseInt(sc.nextLine());

                switch (input) {
                    case 1: // Login
                        System.out.println();
                        System.out.println("  LOGIN PAGE  ");
                        System.out.println("==============");
                        System.out.println();
                        System.out.print("Enter User ID: ");
                        int id = Integer.parseInt(sc.nextLine());
                        if (loginDao.validateUserId(id)) {
                            System.out.print("Enter Password: ");
                            String pass = sc.nextLine();
                            System.out.println();
                            if(loginDao.validatePassword(id,pass)){
                                user = userDao.getUserById(id);
                                System.out.println("Successfully Logged in!!");
                                break homepage;
                            } else {
                                System.out.println("User ID or Password is Wrong!");
                                continue homepage;
                            }
                        } else {
                            System.out.println();
                            System.out.println("Not a Valid User. Please Register!!");
                            continue homepage;
                        }
                    case 2: // register
                        System.out.println();
                        System.out.println("  REGISTER PAGE  ");
                        System.out.println("=================");
                        System.out.println();
                        user = createKnownUser();
                        userDao.addUser(user);
                        System.out.println();
                        System.out.println("Successfully Registered with User Id " + user.getUserId() + "!");
                        continue homepage;
                    case 3: //exit
                        System.out.println();
                        System.out.println("Thank you for using Shopper Den!\nPlease Visit Again!");
                        System.exit(0);
                    default:
                        continue homepage;
                }
            }

            Order order = null;
            Product product = null;

            userhome:
            while (true) {
                System.out.println();
                System.out.println("Welcome " + user.getUserName() + "! Your User Id is " + user.getUserId() + "!");
                System.out.println();
                System.out.println("1. View Products");
                System.out.println("2. My Cart");
                System.out.println("3. My Order");
                System.out.println("4. My Profile");
                System.out.println("5. Logout");
                System.out.println("6. Exit");
                System.out.println();
                System.out.print("Enter Choice: ");
                int input1 = Integer.parseInt(sc.nextLine());

                switch (input1) {
                    case 1: // 1. View all Products
                        System.out.println();
                        System.out.println("  ALL PRODUCTS  ");
                        System.out.println("================");
                        System.out.println();
                        System.out.println("  Product Id  |  Product Name  |  Price  |  Description  ");
                        System.out.println("---------------------------------------------------------");
                        for (Product product1 : productDao.getAllProducts()) {
                            System.out.println(product1.getPid() + "\t| " + product1.getPname() + "\t| "
                                    + product1.getPrice() + "\t| " + product1.getDescription());
                        }
                        continue userhome;
                    case 2: // MY CART
                        mycart:
                        while(true){
                            System.out.println();
                            System.out.println("  MY CART  ");
                            System.out.println("===========");
                            System.out.println();
                            System.out.println("1. Add Product to Cart");
                            System.out.println("2. View All Products in Cart");
                            System.out.println("3. Empty the Cart");
                            System.out.println("4. Place Order");
                            System.out.println("5. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // Add Product to Cart
                                    System.out.println();
                                    System.out.print("Enter Product Id: ");
                                    int proid = Integer.parseInt(sc.nextLine());
                                    product = productDao.getProductById(proid);
                                    if(product==null){
                                        System.out.println("No Product is found with this ID!");
                                    } else {
                                        System.out.print("Enter Quantity: ");
                                        int quan = Integer.parseInt(sc.nextLine());
                                        cartProductsDao.addProductInCart(user, proid, quan);
                                        System.out.println();
                                        System.out.println("Product Added Successfully to Cart!");
                                    }
                                    continue mycart;
                                case 2: // View All Products in Cart
                                    System.out.println();
                                    System.out.println("  Product ID  |  Product Name  |  Price  |  Quantity  ");
                                    System.out.println("------------------------------------------------------");
                                    for (CartProducts cartProducts : cartProductsDao.getAllProductInCart(user)) {
                                        System.out.println(cartProducts.getProduct().getPid() + "\t| "
                                                + cartProducts.getProduct().getPname() + "\t| "
                                                + cartProducts.getProduct().getPrice() + "\t| "
                                                + cartProducts.getQuantity());
                                    }
                                    continue mycart;
                                case 3:
                                    System.out.println();
                                    cartProductsDao.emptyUserCart(user);
                                    System.out.println("Your Cart is Emptied successfully!");
                                    continue userhome;
                                case 4: // Place Order
                                    System.out.println();
                                    order = createOrder(user);
                                    orderDao.placeOrder(user, order);
                                    System.out.println("Order Placed Successfully with Order ID " + order.getOrderId()
                                            + "!\nPlease Proceed to Pay " + order.getAmount() + " for the Order!\nThank You!");
                                    continue mycart;
                                default:
                                    continue userhome;
                            }
                        }
                    case 3: // My ORDER
                        myorder:
                        while(true) {
                            System.out.println();
                            System.out.println("  MY ORDER  ");
                            System.out.println("============");
                            System.out.println();
                            System.out.println("1. View Placed Order (by Order ID)");
                            System.out.println("2. Cancel Order");
                            System.out.println("3. Pay for Placed Order");
                            System.out.println("4. View Previous Orders (Paid)");
                            System.out.println("5. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // View Placed Order (by Order ID)
                                    System.out.println();
                                    if (order == null) {
                                        System.out.print("Enter Order Id: ");
                                        order = orderDao.getOrderById(Integer.parseInt(sc.nextLine()));
                                    }
                                    if (order == null) {
                                        System.out.println("No Order is found with this ID!");
                                        continue myorder;
                                    }
                                    System.out.println("Order Details:\nOrder ID: " + order.getOrderId());
                                    System.out.println("Date Placed: " + order.getDatePlaced());
                                    System.out.println("Amount: " + order.getAmount());
                                    continue myorder;
                                case 2: // 2. Cancel Order
                                    System.out.println();
                                    if (order == null) {
                                        System.out.print("Enter Order Id: ");
                                        order = orderDao.getOrderById(Integer.parseInt(sc.nextLine()));
                                    }
                                    if (order == null) {
                                        System.out.println("No Order is found with this ID!");
                                        continue myorder;
                                    }
                                    orderDao.cancelOrder(order.getOrderId());
                                    order = null;
                                    System.out.println("Your Order is cancelled successfully!");
                                    continue myorder;
                                case 3: // 3. Pay for Placed Order
                                    System.out.println();
                                    if (order == null) {
                                        System.out.print("Enter Order Id: ");
                                        order = orderDao.getOrderById(Integer.parseInt(sc.nextLine()));
                                    }
                                    if (order == null) {
                                        System.out.println("No Order is found with this ID!");
                                        continue myorder;
                                    }
                                    System.out.print("Choose Payment Mode (Debit | Credit | UPI | COD): ");
                                    String mode = sc.nextLine();
                                    orderDao.confirmOrder(user, order.getOrderId(), mode);
                                    System.out.println();
                                    System.out.println("Your Order with Order ID " + order.getOrderId() + " is paid successfully!");
                                    order = null;
                                    continue myorder;
                                case 4: // 4. View Previous Orders (Paid)
                                    System.out.println();
                                    System.out.println("  Order History  ");
                                    System.out.println("=================");
                                    System.out.println();
                                    System.out.println("  Order Id  |  Date Placed  |  Date Delivered  |  Amount  |  Payment Mode  ");
                                    System.out.println("---------------------------------------------------------------------------");
                                    for (Order order1 : orderDao.viewAllOrder(user.getUserId())) {
                                        System.out.println(order1.getOrderId() + "\t| "
                                                + order1.getDatePlaced() + "\t| "
                                                + order1.getDateDelivered() + "\t| "
                                                + order1.getAmount() + "\t| "
                                                + order1.getPaymentMode());
                                    }
                                    continue myorder;
                                default:
                                    continue userhome;
                            }
                        }
                    case 4: // My PROFILE
                        myprofile:
                        while(true) {
                            System.out.println();
                            System.out.println("  MY PROFILE  ");
                            System.out.println("==============");
                            System.out.println();
                            System.out.println("1. View Profile");
                            System.out.println("2. Update Profile");
                            System.out.println("3. Delete Profile");
                            System.out.println("4. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // View Profile
                                    user = userDao.getUserById(user.getUserId());
                                    System.out.println();
                                    System.out.println("  Profile Details  ");
                                    System.out.println("-------------------");
                                    System.out.println("User ID: " + user.getUserId());
                                    System.out.println("User Name: " + user.getUserName());
                                    System.out.println("User Email: " + user.getEmail());
                                    System.out.println("User Phone Number: " + user.getPhone());
                                    System.out.println("User Address: " + user.getAddress());
                                    continue myprofile;
                                case 2: // Update Profile
                                    System.out.println();
                                    System.out.println("  Update Profile  ");
                                    System.out.println("------------------");
                                    System.out.println();
                                    System.out.println("1. Update Name");
                                    System.out.println("2. Update Password");
                                    System.out.println("3. Update Address");
                                    System.out.println("4. Update Phone Number");
                                    System.out.println("5: Go Back");
                                    System.out.print("Enter Choice: ");
                                    int input3 = Integer.parseInt(sc.nextLine());
                                    System.out.println();
                                    switch (input3) {
                                        case 1:
                                            System.out.print("Enter New Name: ");
                                            userDao.updateUserName(user.getUserId(), sc.nextLine());
                                            break;
                                        case 2:
                                            System.out.print("Enter New Password: ");
                                            userDao.updateUserPass(user.getUserId(), sc.nextLine());
                                            break;
                                        case 3:
                                            System.out.print("Enter New Address: ");
                                            userDao.updateUserAddress(user.getUserId(), sc.nextLine());
                                            break;
                                        case 4:
                                            System.out.print("Enter New Phone Number: ");
                                            userDao.updateUserPhone(user.getUserId(), Long.parseLong(sc.nextLine()));
                                            break;
                                        default:
                                            continue myprofile;
                                    }
                                    System.out.println();
                                    System.out.println("Your Profile is updated successfully!");
                                    continue myprofile;
                                case 3: // Delete Profile
                                    System.out.println("\n");
                                    System.out.print("Are you sure you want to delete your profile?\n" +
                                            "NOTE: You can't undo this action!\nEnter Choice [Y|N]: ");
                                    String response = sc.nextLine().toLowerCase();
                                    if (response.equals("y")) {
                                        userDao.deleteUser(user.getUserId());
                                        System.out.println("Profile deleted successfully!");
                                        System.out.println("\nThank you for using Shopper Den!\nPlease Visit Again!\n");
                                        continue top;
                                    }
                                    continue myprofile;
                                default:
                                    continue userhome;
                            }
                        }
                    case 5: // Logout
                        System.out.println("\nLogged Out successfully!");
                        System.out.println("\nThank you for using Shopper Den!\nPlease Visit Again!\n");
                        System.out.println("------------------------------------------\n");
                        continue top;
                    case 6: // Exit
                        System.out.println("\nThank you for using Shopper Den!\nPlease Visit Again!\n");
                        System.out.println("------------------------------------------\n");
                        System.exit(0);
                    default:
                        continue userhome;
                }
            }
        }


        // For User Methods
//        UserDao userDao = new UserImpl();
        // For Adding Users
//        for(int i=0;i<9;i++) {
//            userDao.addUser(createRandomUser());
//        }
        // For Updating User Data
//        userDao.updateUserPass(2574,"8765456");
        // For Displaying all users
//        for(User user : userDao.getAllUsers()){
//            System.out.println(user.getUserId()+" "+user.getUserName()+" "+user.getUserRole());
//        }
        // For Deleting User
//        userDao.deleteUser(746);
        // For getting one user by id
//        User user = userDao.getUserById(179);
//        System.out.println(user.getUserId()+" "+user.getUserName()+" "+user.getCart().getCartId());


        // For Category Methods
//        CategoryDao categoryDao = new CategoryImpl();
        // For Adding Categories
//        for(int i=0;i<9;i++) {
//            categoryDao.addCategory(createRandomCategory());
//        }
//        categoryDao.addCategory(createKnownCategory());
        // For updating category
//        categoryDao.updateCategory(30,"J8Ghbjg6");
        // For displaying category
//        for(Category category: categoryDao.getAllCategories()){
//            System.out.println(category.getCid()+" "+category.getCname());
//        }


        // For Product Methods
//        ProductDao productDao = new ProductImpl();
        // Add products
//        for(int i=0;i<10;i++) {
//            productDao.addProduct(createRandomProduct());
//        }
        // delete product
//        productDao.deleteProduct(7111);
        // update product
//        productDao.updateProductName(4413,"fY6RKj7");
        // displaying products
//        for(Product product: productDao.getAllProducts()){
//            System.out.println(product.getPid()+" "+product.getPname()+" "+product.getPrice());
//        }
        // displaying one product by id
//        Product product = productDao.getProductById(7727);
//        System.out.println(product.getPid()+" "+product.getPname()+" "+product.getPrice());


        // For CartProducts Methods
//        UserDao userDao = new UserImpl();
//        User user = userDao.getUserById(171);
//
//        CartProductsDao cartProductsDao = new CartProductsImpl();
        // Add product in cart
//        cartProductsDao.addProductInCart(user,1547,1);
//        cartProductsDao.addProductInCart(user,4413,2);

        // delete product in cart
//        cartProductsDao.deleteProductInCart(user,4413);
        // display products in cart
//        for(CartProducts cartProducts: cartProductsDao.getAllProductInCart(user)){
//            System.out.println(cartProducts.getCart().getCartId()+" "+cartProducts.getProduct().getPname()+" "
//                    +cartProducts.getQuantity()+" "+cartProducts.getDateAdded());
//        }
        // Empty User Cart
//        cartProductsDao.emptyUserCart(user);


        // For Order Methods
//        UserDao userDao = new UserImpl();
//        User user = userDao.getUserById(701);
//        OrderDao orderDao = new OrderImpl();
//        orderDao.placeOrder(user,createOrder(user));
//        orderDao.cancelOrder(5421);
//        orderDao.confirmOrder(user,3323,sc);
        // Display Orders by order id
//        Order order = orderDao.getOrderById(2072);
//        System.out.println(order.getOrderId()+" "+order.getDateDelivered()+" "
//                +order.getAmount()+" "+order.getPaymentMode()+" "+order.isPaid());
        // Display All order by User
//        for(Order order: orderDao.viewAllOrder(701)){
//            System.out.println(order.getOrderId()+" "+order.getDateDelivered()+" "+order.getAmount()+" "+order.isPaid());
//        }
    }

    private static Order createOrder(User user) throws SQLException {
        CartDao cartDao = new CartImpl();
        CartProductsDao cartProductsDao = new CartProductsImpl();
        int amount=0;
        for(CartProducts cartProducts : cartProductsDao.getAllProductInCart(user)) {
            amount+=cartProducts.getQuantity()*cartProducts.getProduct().getPrice();
        }

        Order order = new Order();
        order.setOrderId(new Random().nextInt(10000));
        order.setDatePlaced(LocalDate.now());
        order.setCart(cartDao.getCartByUser(user));
        order.setUser(user);
        order.setAmount(amount);
        order.setPaid(false);
        return order;
    }

    private static Product createRandomProduct() {
        Product product=new Product();
        product.setPid(1+new Random().nextInt(10000));
        product.setPname(getAlphaNumericString(7));
        product.setDate(LocalDate.now().minus(new Random().nextInt(30), ChronoUnit.DAYS));
        product.setPrice(100+new Random().nextInt(10000));
        product.setQuantity(2+new Random().nextInt(10));
        product.setDescription(getAlphaNumericString(12));
        Category c=new Category();
        c.setCid(30);
        product.setCategory(c);
        return product;
    }

    private static Product createKnownProduct() {
        Product product=new Product();
        product.setPid(1+new Random().nextInt(10000));
        System.out.print("Enter Product Name: ");
        product.setPname(sc.nextLine());
        product.setDate(LocalDate.now().minus(new Random().nextInt(30), ChronoUnit.DAYS));
        System.out.print("Enter Price of Product: ");
        product.setPrice(Integer.parseInt(sc.nextLine()));
        System.out.print("Enter Quantity of Product: ");
        product.setQuantity(Integer.parseInt(sc.nextLine()));
        System.out.print("Enter Description of Product: ");
        product.setDescription(sc.nextLine());
        Category c=new Category();
        System.out.print("Enter Product Category ID: ");
        c.setCid(Integer.parseInt(sc.nextLine()));
        product.setCategory(c);
        return product;
    }

    private static Category createRandomCategory() {
        Category category = new Category();
        category.setCid(1+new Random().nextInt(100));
        category.setCname(getAlphaNumericString(8));
        return category;
    }

    private static Category createKnownCategory() {
        Category category = new Category();
        category.setCid(1+new Random().nextInt(100));
        System.out.print(" Enter Category Name: ");
        category.setCname(sc.nextLine());
        return category;
    }

    private static User createRandomUser() {
        User user = new User();
        user.setUserId(1+new Random().nextInt(1000));
        user.setUserName(getAlphaNumericString(6));
        user.setEmail(getAlphaNumericString(6)+"@gmail.com");
        user.setPassword(getAlphaNumericString(8));
        user.setSecQue(getAlphaNumericString(10));
        user.setAnswer(getAlphaNumericString(5));
        user.setAddress(getAlphaNumericString(7));
        user.setPhone(912345678 + new Random().nextInt(100000));
        if (new Random().nextInt(2) == 0) {
            user.setUserRole(UserRole.CUSTOMER);
        } else {
            user.setUserRole(UserRole.ADMIN);
        }
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(1000));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    private static User createKnownUser() {
        User user = new User();
        user.setUserId(1+new Random().nextInt(1000));
        System.out.print("Enter User Name: ");
        user.setUserName(sc.nextLine());
        System.out.print("Enter Email: ");
        user.setEmail(sc.nextLine());
        System.out.print("Enter Password: ");
        user.setPassword(sc.nextLine());
        System.out.print("Enter Security Question: ");
        user.setSecQue(sc.nextLine());
        System.out.print("Enter Security Answer: ");
        user.setAnswer(sc.nextLine());
        System.out.print("Enter Address: ");
        user.setAddress(sc.nextLine());
        System.out.print("Enter Phone No.: ");
        user.setPhone(Long.parseLong(sc.nextLine()));
//        System.out.print("Enter Role (0-Customer | 1-Admin): ");
//        if (Integer.parseInt(sc.nextLine()) == 0) {
            user.setUserRole(UserRole.CUSTOMER);
//        } else {
//            user.setUserRole(UserRole.ADMIN);
//        }
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(1000));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    public static String getAlphaNumericString(int n) {
        // length is bounded by 256 Character
        byte[] array = new byte[256];
        new Random().nextBytes(array);
        String randomString = new String(array, Charset.forName("UTF-8"));
        // Create a StringBuffer to store the result
        StringBuffer r = new StringBuffer();
        // Append first 20 alphanumeric characters
        // from the generated random String into the result
        for (int k = 0; k < randomString.length(); k++) {
            char ch = randomString.charAt(k);
            if (((ch >= 'a' && ch <= 'z')
                    || (ch >= 'A' && ch <= 'Z')
                    || (ch >= '0' && ch <= '9'))
                    && (n > 0)) {
                r.append(ch);
                n--;
            }
        }
        // return the resultant string
        return r.toString();
    }
}
