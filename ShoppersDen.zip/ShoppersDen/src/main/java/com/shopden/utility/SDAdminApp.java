package com.shopden.utility;

import com.shopden.dao.*;
import com.shopden.models.*;

import java.nio.charset.Charset;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class SDAdminApp {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        UserDao userDao = new UserImpl();   // For User Methods
        ProductDao productDao = new ProductImpl();  // For Product Methods
        CartProductsDao cartProductsDao = new CartProductsImpl();   // For CartProducts Methods
        OrderDao orderDao = new OrderImpl();    // For Order Methods
        LoginDao loginDao = new LoginImpl();    // For Login Methods
        CategoryDao categoryDao = new CategoryImpl(); // For Category Methods

        User user = null;
        Order order = null;
        Product product = null;
        Category category = null;

        top:
        while (true) {

            homepage:
            while (true) {
                System.out.println();
                System.out.println("==============================================");
                System.out.println("Welcome to Administrator Shoppers Den Website!");
                System.out.println("==============================================");
                System.out.println();
                System.out.println("1. Login");
                System.out.println("2. Exit");
                System.out.println();
                System.out.print("Enter Choice: ");
                int input = Integer.parseInt(sc.nextLine());

                switch (input) {
                    case 1: // Login
                        System.out.println();
                        System.out.println("  LOGIN PAGE  ");
                        System.out.println("==============");
                        System.out.println();
                        System.out.print("Enter User ID: ");
                        int id = Integer.parseInt(sc.nextLine());
                        if (loginDao.validateUserId(id)) {
                            System.out.print("Enter Password: ");
                            String pass = sc.nextLine();
                            System.out.println();
                            if(loginDao.validatePassword(id,pass)){
                                if(loginDao.validateAdminAccess(id)){
                                    user = userDao.getUserById(id);
                                    System.out.println("Successfully Logged in!!");
                                    break homepage;
                                } else {
                                    System.out.println("Not a Valid Admin. Access Denied!");
                                    System.exit(0);
                                }
                            } else {
                                System.out.println("Admin ID or Password is Wrong!");
                                continue homepage;
                            }
                        } else {
                            System.out.println();
                            System.out.println("Not a Valid Admin. Please Register!!");
                            continue homepage;
                        }
                    case 2: //exit
                        System.out.println();
                        System.out.println("Thank you for using Shopper Den!\nPlease Visit Again!");
                        System.exit(0);
                    case 123: // register - Hidden from a normal user
                        System.out.println();
                        System.out.println("  REGISTER PAGE  ");
                        System.out.println("=================");
                        System.out.println();
                        user = createKnownUser();
                        userDao.addUser(user);
                        System.out.println();
                        System.out.println("Successfully Registered with Admin Id " + user.getUserId() + "!");
                        continue homepage;
                    default:
                        continue homepage;
                }
            }

            adminhome:
            while (true) {
                System.out.println();
                System.out.println("Welcome " + user.getUserName() + "! Your Admin Id is " + user.getUserId() + "!");
                System.out.println();
                System.out.println("1. User Actions");
                System.out.println("2. Category Actions");
                System.out.println("3. Product Actions");
                System.out.println("4. Order Actions");
                System.out.println("5. My Profile");
                System.out.println("6. Register New Admin");
                System.out.println("7. Logout");
                System.out.println("8. Exit");
                System.out.println();
                System.out.print("Enter Choice: ");
                int input1 = Integer.parseInt(sc.nextLine());

                switch (input1) {
                    case 1: // 1. View all Users
                        useraction:
                        while (true) {
                            System.out.println();
                            System.out.println("User Actions:");
                            System.out.println("1. View all Users");
                            System.out.println("2. View User Details (by User ID)");
                            System.out.println("3. Delete User");
                            System.out.println("4. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // View all Users
                                    System.out.println();
                                    System.out.println("  User ID  |  User Name  |  Email  |  Phone No  |  Role  |  Cart ID  ");
                                    System.out.println("---------------------------------------------------------------------");
                                    for (User user1 : userDao.getAllUsers()) {
                                        System.out.println(user1.getUserId() + "\t| " + user1.getUserName() + "\t| "
                                                + user1.getEmail() + "\t| " + user1.getPhone() + "\t| " + user1.getUserRole() + "\t| "
                                                + user1.getCart().getCartId());
                                    }
                                    continue useraction;
                                case 2: // View User Details (by User ID)
                                    System.out.println();
                                    System.out.print("Enter User ID: ");
                                    int getid = Integer.parseInt(sc.nextLine());
                                    User user1 = userDao.getUserById(getid);
                                    System.out.println();
                                    if (user1 == null) {
                                        System.out.println("No User found with entered Used ID!");
                                    } else {
                                        System.out.println("  User ID  |  User Name  |  Email  |  Phone No  |  Role  |  Cart ID  ");
                                        System.out.println("---------------------------------------------------------------------");
                                        System.out.println(user1.getUserId() + "\t| " + user1.getUserName() + "\t| "
                                                + user1.getEmail() + "\t| " + user1.getPhone() + "\t| " + user1.getUserRole() + "\t| "
                                                + user1.getCart().getCartId());
                                    }
                                    continue useraction;
                                case 3: // 3. Delete User
                                    System.out.println();
                                    System.out.print("Enter User ID to delete: ");
                                    int delid = Integer.parseInt(sc.nextLine());
                                    User checkuser = userDao.getUserById(delid);
                                    System.out.println("");
                                    if(checkuser==null){
                                        System.out.println("No User is found with this ID!");
                                    } else {
                                        System.out.print("Are you sure you want to delete your profile?\n" +
                                                "NOTE: You can't undo this action!\nEnter Choice [Y|N]: ");
                                        String response = sc.nextLine().toLowerCase();
                                        if (response.equals("y")) {
                                            userDao.deleteUser(delid);
                                            System.out.println("Profile deleted successfully!");
                                        }
                                    }
                                    continue useraction;
                                default: // Go Back
                                    continue adminhome;
                            }
                        }
                    case 2: // 2. Category Actions
                        categoryaction:
                        while (true) {
                            System.out.println();
                            System.out.println("Category Actions:");
                            System.out.println("1. View All Categories");
                            System.out.println("2. View Category (by ID)");
                            System.out.println("3. Add Category");
                            System.out.println("4. Update Category Name");
                            System.out.println("5. Delete Category");
                            System.out.println("6. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // View All Categories
                                    System.out.println();
                                    System.out.println("  Category ID  |  Category Name  ");
                                    System.out.println("---------------------------------");
                                    for(Category category1: categoryDao.getAllCategories()){
                                        System.out.println(category1.getCid()+"\t| "+category1.getCname());
                                    }
                                    continue categoryaction;
                                case 2: // View Category (by ID)
                                    System.out.println();
                                    System.out.print("Enter Category ID: ");
                                    category = categoryDao.getCategoryById(Integer.parseInt(sc.nextLine()));
                                    System.out.println();
                                    if(category==null){
                                        System.out.println("No Category found with this ID!");
                                    } else {
                                        System.out.println("Category ID: "+category.getCid());
                                        System.out.println("Category Name: "+category.getCname());
                                    }
                                    continue categoryaction;
                                case 3: // 3. Add Category
                                    System.out.println();
                                    Category category1 = createKnownCategory();
                                    categoryDao.addCategory(category1);
                                    System.out.println();
                                    System.out.println("Category successfully added with ID "+category1.getCid()+"!");
                                    continue categoryaction;
                                case 4: // 4. Update Category Name
                                    System.out.println();
                                    System.out.print("Enter category ID: ");
                                    int catid = Integer.parseInt(sc.nextLine());
                                    category = categoryDao.getCategoryById(catid);
                                    System.out.println();
                                    if(category==null){
                                        System.out.println("No Category found with this ID!");
                                    } else{
                                        System.out.print("Enter New Category Name: ");
                                        categoryDao.updateCategory(catid,sc.nextLine());
                                        System.out.println("\nCategory successfully Updated!");
                                    }
                                    continue categoryaction;
                                case 5: // 5. Delete Category
                                    System.out.println();
                                    System.out.print("Enter category ID: ");
                                    int delcatid = Integer.parseInt(sc.nextLine());
                                    category = categoryDao.getCategoryById(delcatid);
                                    System.out.println();
                                    if(category==null){
                                        System.out.println("No Category found with this ID!");
                                    } else{
                                        categoryDao.deleteCategory(delcatid);
                                        System.out.println("Category successfully Deleted!");
                                    }
                                    continue categoryaction;
                                default:
                                    continue adminhome;
                            }
                        }
                    case 3: // 3. Product Actions
                        productaction:
                        while (true) {
                            System.out.println();
                            System.out.println("Product Actions:");
                            System.out.println("1. View All Products");
                            System.out.println("2. View product (by Product ID)");
                            System.out.println("3. Add Product");
                            System.out.println("4. Update Product");
                            System.out.println("5. Delete Product");
                            System.out.println("6. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // View All Products
                                    System.out.println();
                                    System.out.println("  Product ID  |  Product Name  |  Price  |  Quantity  " +
                                            "|  Date Added  |  Description  |  Category Name  ");
                                    System.out.println("------------------------------------------------------" +
                                            "-------------------------------------------------");
                                    for (Product product1 : productDao.getAllProducts()) {
                                        System.out.println(product1.getPid() + "\t| "
                                                + product1.getPname() + "\t| "
                                                + product1.getPrice() + "\t| "
                                                + product1.getQuantity() + "\t| "
                                                + product1.getDate() + "\t| "
                                                + product1.getDescription().substring(0, 8) + "\t| "
                                                + product1.getCategory().getCname());
                                    }
                                    continue productaction;
                                case 2: // View product (by Product ID)
                                    System.out.println();
                                    System.out.print("Enter Product ID: ");
                                    int pid2 = Integer.parseInt(sc.nextLine());
                                    Product product1 = productDao.getProductById(pid2);
                                    if (product1 == null) {
                                        System.out.println("No Product with this Product ID!");
                                    } else {
                                        System.out.println("  Product ID  |  Product Name  |  Price  |  Quantity  " +
                                                "|  Date Added  |  Description  |  Category Name  ");
                                        System.out.println("------------------------------------------------------" +
                                                "-------------------------------------------------");
                                        System.out.println(product1.getPid() + "\t| "
                                                + product1.getPname() + "\t| "
                                                + product1.getPrice() + "\t| "
                                                + product1.getQuantity() + "\t| "
                                                + product1.getDate() + "\t| "
                                                + product1.getDescription().substring(0, 8) + "\t| "
                                                + product1.getCategory().getCname());
                                    }
                                    continue productaction;
                                case 3: // Add Product
                                    System.out.println();
                                    product = createKnownProduct();
                                    productDao.addProduct(product);
                                    System.out.println("Product added successfully with product ID " + product.getPid() + "!");
                                    continue productaction;
                                case 4: // Update Product
                                    System.out.println();
                                    System.out.print("Enter Product ID for updating: ");
                                    int updateid = Integer.parseInt(sc.nextLine());
                                    product1 = productDao.getProductById(updateid);
                                    System.out.println();
                                    if (product1 == null) {
                                        System.out.println("No Product Found by this ID!");
                                    } else {
                                        System.out.println("\nWhat do you want to change?");
                                        System.out.println("1. Update Name");
                                        System.out.println("2. Update Quantity");
                                        System.out.println("3. Update Price");
                                        System.out.println("4. Update Description");
                                        System.out.println("5: Go Back");
                                        System.out.print("Enter Choice: ");
                                        int input3 = Integer.parseInt(sc.nextLine());
                                        switch (input3) {
                                            case 1:
                                                System.out.print("Enter New Name: ");
                                                productDao.updateProductName(updateid, sc.nextLine());
                                                break;
                                            case 2:
                                                System.out.print("Enter New Quantity: ");
                                                productDao.updateProductQuantity(updateid, Integer.parseInt(sc.nextLine()));
                                                break;
                                            case 3:
                                                System.out.print("Enter New Price: ");
                                                productDao.updateProductPrice(updateid, Integer.parseInt(sc.nextLine()));
                                                break;
                                            case 4:
                                                System.out.print("Enter New Description: ");
                                                productDao.updateProductDescription(updateid, sc.nextLine());
                                                break;
                                            default:
                                                continue productaction;
                                        }
                                        System.out.println();
                                        System.out.println("Your Product is updated successfully!");
                                    }
                                    continue productaction;
                                case 5: // Delete Product
                                    System.out.println();
                                    System.out.print("Enter Product ID for deleting: ");
                                    int deleteid = Integer.parseInt(sc.nextLine());
                                    productDao.deleteProduct(deleteid);
                                    System.out.println("\nProduct is successfully deleted!");
                                    continue productaction;
                                default: // Go Back
                                    continue adminhome;
                            }
                        }
                    case 4: // 4. Order Actions
                        orderaction:
                        while (true) {
                            System.out.println();
                            System.out.println("Order Actions:");
                            System.out.println("1. View All Orders (by User ID)");
                            System.out.println("2. View Order (by Order ID)");
                            System.out.println("3. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // 1. View All Orders (by User ID)
                                    System.out.println();
                                    System.out.print("Enter User ID: ");
                                    int user2 = Integer.parseInt(sc.nextLine());
                                    User user1 = null;
                                    user1 = userDao.getUserById(user2);
                                    System.out.println();
                                    if (user1 == null) {
                                        System.out.println("No User found with this ID!");
                                    } else {
                                        System.out.println("  Order Id  |  Date Placed  |  Date Delivered" +
                                                "  |  Amount  |  Payment Mode  |  Paid  ");
                                        System.out.println("---------------------------------------------" +
                                                "---------------------------------------");
                                        for (Order order1 : orderDao.viewAllOrder(user2)) {
                                            System.out.print(order1.getOrderId() + "\t| "
                                                    + order1.getDatePlaced() + "\t| "
                                                    + order1.getDateDelivered() + "\t| "
                                                    + order1.getAmount() + "\t| "
                                                    + order1.getPaymentMode() + "\t| ");
                                            if (order1.isPaid()) {
                                                System.out.println("Yes");
                                            } else {
                                                System.out.println("No");
                                            }
                                        }
                                    }
                                    continue orderaction;
                                case 2: // View Order (By Order ID)
                                    System.out.println();
                                    System.out.print("Enter Order Id: ");
                                    order = orderDao.getOrderById(Integer.parseInt(sc.nextLine()));
                                    if (order == null) {
                                        System.out.println("No Order is found with this ID!");
                                        continue orderaction;
                                    }
                                    System.out.println();
                                    System.out.println("  Order Id  |  Date Placed  |  Date Delivered" +
                                            "  |  Amount  |  Payment Mode  |  Paid  ");
                                    System.out.println("---------------------------------------------" +
                                            "---------------------------------------");
                                    System.out.print(order.getOrderId() + "\t| "
                                            + order.getDatePlaced() + "\t| "
                                            + order.getDateDelivered() + "\t| "
                                            + order.getAmount() + "\t| "
                                            + order.getPaymentMode() + "\t| ");
                                    if (order.isPaid()) {
                                        System.out.println("Paid");
                                    } else {
                                        System.out.println("Not Paid");
                                    }
                                    continue orderaction;
                                default:
                                    continue adminhome;
                            }
                        }
                    case 5: // MY PROFILE
                        myprofile:
                        while(true) {
                            System.out.println();
                            System.out.println("  MY PROFILE  ");
                            System.out.println("==============");
                            System.out.println();
                            System.out.println("1. View Profile");
                            System.out.println("2. Update Profile");
                            System.out.println("3. Delete Profile");
                            System.out.println("4. Go Back");
                            System.out.print("Enter Choice: ");
                            int input2 = Integer.parseInt(sc.nextLine());
                            switch (input2) {
                                case 1: // View Profile
                                    user = userDao.getUserById(user.getUserId());
                                    System.out.println();
                                    System.out.println("  Profile Details  ");
                                    System.out.println("-------------------");
                                    System.out.println("User ID: " + user.getUserId());
                                    System.out.println("User Name: " + user.getUserName());
                                    System.out.println("User Email: " + user.getEmail());
                                    System.out.println("User Phone Number: " + user.getPhone());
                                    System.out.println("User Address: " + user.getAddress());
                                    continue myprofile;
                                case 2: // Update Profile
                                    System.out.println();
                                    System.out.println("  Update Profile  ");
                                    System.out.println("------------------");
                                    System.out.println();
                                    System.out.println("1. Update Name");
                                    System.out.println("2. Update Password");
                                    System.out.println("3. Update Address");
                                    System.out.println("4. Update Phone Number");
                                    System.out.println("5: Go Back");
                                    System.out.print("Enter Choice: ");
                                    int input3 = Integer.parseInt(sc.nextLine());
                                    System.out.println();
                                    switch (input3) {
                                        case 1:
                                            System.out.print("Enter New Name: ");
                                            userDao.updateUserName(user.getUserId(), sc.nextLine());
                                            break;
                                        case 2:
                                            System.out.println("Enter New Password: ");
                                            userDao.updateUserPass(user.getUserId(), sc.nextLine());
                                            break;
                                        case 3:
                                            System.out.println("Enter New Address: ");
                                            userDao.updateUserAddress(user.getUserId(), sc.nextLine());
                                            break;
                                        case 4:
                                            System.out.println("Enter New Phone Number: ");
                                            userDao.updateUserPhone(user.getUserId(), Long.parseLong(sc.nextLine()));
                                            break;
                                        default:
                                            continue myprofile;
                                    }
                                    System.out.println();
                                    System.out.println("Your Profile is updated successfully!");
                                    continue myprofile;
                                case 3: // Delete Profile
                                    System.out.println("\n");
                                    System.out.print("Are you sure you want to delete your profile?\n" +
                                            "NOTE: You can't undo this action!\nEnter Choice [Y|N]: ");
                                    String response = sc.nextLine().toLowerCase();
                                    if (response.equals("y")) {
                                        userDao.deleteUser(user.getUserId());
                                        System.out.println("Profile deleted successfully!");
                                        System.out.println("\nThank you for using Shopper Den!\nPlease Visit Again!\n");
                                        continue top;
                                    }
                                    continue myprofile;
                                default:
                                    continue adminhome;
                            }
                        }
                    case 6: // Register new Admin
                        System.out.println();
                        System.out.println("  ADMIN REGISTER PAGE  ");
                        System.out.println("=======================");
                        System.out.println();
                        user = createKnownUser();
                        userDao.addUser(user);
                        System.out.println();
                        System.out.println("Successfully Registered with Admin Id " + user.getUserId() + "!");
                        continue adminhome;
                    case 7: // Logout
                        System.out.println("\nLogged Out successfully!");
                        System.out.println("\nThank you for using Shopper Den!\nPlease Visit Again!\n");
                        System.out.println("------------------------------------------\n");
                        continue top;
                    case 8: // Exit
                        System.out.println("\nThank you for using Shopper Den!\nPlease Visit Again!\n");
                        System.out.println("------------------------------------------\n");
                        System.exit(0);
                    default:
                        break adminhome;
                }
            }
        }
    }

    private static Order createOrder(User user) throws SQLException {
        CartDao cartDao = new CartImpl();
        CartProductsDao cartProductsDao = new CartProductsImpl();
        int amount=0;
        for(CartProducts cartProducts : cartProductsDao.getAllProductInCart(user)) {
            amount+=cartProducts.getQuantity()*cartProducts.getProduct().getPrice();
        }

        Order order = new Order();
        order.setOrderId(new Random().nextInt(10000));
        order.setDatePlaced(LocalDate.now());
        order.setCart(cartDao.getCartByUser(user));
        order.setUser(user);
        order.setAmount(amount);
        order.setPaid(false);
        return order;
    }

    private static Product createRandomProduct() {
        Product product=new Product();
        product.setPid(1+new Random().nextInt(10000));
        product.setPname(getAlphaNumericString(7));
        product.setDate(LocalDate.now().minus(new Random().nextInt(30), ChronoUnit.DAYS));
        product.setPrice(100+new Random().nextInt(10000));
        product.setQuantity(2+new Random().nextInt(10));
        product.setDescription(getAlphaNumericString(12));
        Category c=new Category();
        c.setCid(30);
        product.setCategory(c);
        return product;
    }

    private static Product createKnownProduct() {
        Product product=new Product();
        product.setPid(1+new Random().nextInt(10000));
        System.out.print("Enter Product Name: ");
        product.setPname(sc.nextLine());
        product.setDate(LocalDate.now().minus(new Random().nextInt(30), ChronoUnit.DAYS));
        System.out.print("Enter Price of Product: ");
        product.setPrice(Integer.parseInt(sc.nextLine()));
        System.out.print("Enter Quantity of Product: ");
        product.setQuantity(Integer.parseInt(sc.nextLine()));
        System.out.print("Enter Description of Product: ");
        product.setDescription(sc.nextLine());
        Category c=new Category();
        System.out.print("Enter Product Category ID: ");
        c.setCid(Integer.parseInt(sc.nextLine()));
        product.setCategory(c);
        return product;
    }

    private static Category createRandomCategory() {
        Category category = new Category();
        category.setCid(1+new Random().nextInt(100));
        category.setCname(getAlphaNumericString(8));
        return category;
    }

    private static Category createKnownCategory() {
        Category category = new Category();
        category.setCid(1+new Random().nextInt(100));
        System.out.print("Enter Category Name: ");
        category.setCname(sc.nextLine());
        return category;
    }

    private static User createRandomUser() {
        User user = new User();
        user.setUserId(1+new Random().nextInt(1000));
        user.setUserName(getAlphaNumericString(6));
        user.setEmail(getAlphaNumericString(6)+"@gmail.com");
        user.setPassword(getAlphaNumericString(8));
        user.setSecQue(getAlphaNumericString(10));
        user.setAnswer(getAlphaNumericString(5));
        user.setAddress(getAlphaNumericString(7));
        user.setPhone(912345678 + new Random().nextInt(100000));
        if (new Random().nextInt(2) == 0) {
            user.setUserRole(UserRole.CUSTOMER);
        } else {
            user.setUserRole(UserRole.ADMIN);
        }
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(1000));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    private static User createKnownUser() {
        User user = new User();
        user.setUserId(1+new Random().nextInt(1000));
        System.out.print("Enter User Name: ");
        user.setUserName(sc.nextLine());
        System.out.print("Enter Email: ");
        user.setEmail(sc.nextLine());
        System.out.print("Enter Password: ");
        user.setPassword(sc.nextLine());
        System.out.print("Enter Security Question: ");
        user.setSecQue(sc.nextLine());
        System.out.print("Enter Security Answer: ");
        user.setAnswer(sc.nextLine());
        System.out.print("Enter Address: ");
        user.setAddress(sc.nextLine());
        System.out.print("Enter Phone No.: ");
        user.setPhone(Long.parseLong(sc.nextLine()));
//        System.out.print("Enter Role (0-Customer | 1-Admin): ");
//        if (Integer.parseInt(sc.nextLine()) == 0) {
//        user.setUserRole(UserRole.CUSTOMER);
//        } else {
            user.setUserRole(UserRole.ADMIN);
//        }
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(1000));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    public static String getAlphaNumericString(int n) {
        // length is bounded by 256 Character
        byte[] array = new byte[256];
        new Random().nextBytes(array);
        String randomString = new String(array, Charset.forName("UTF-8"));
        // Create a StringBuffer to store the result
        StringBuffer r = new StringBuffer();
        // Append first 20 alphanumeric characters
        // from the generated random String into the result
        for (int k = 0; k < randomString.length(); k++) {
            char ch = randomString.charAt(k);
            if (((ch >= 'a' && ch <= 'z')
                    || (ch >= 'A' && ch <= 'Z')
                    || (ch >= '0' && ch <= '9'))
                    && (n > 0)) {
                r.append(ch);
                n--;
            }
        }
        // return the resultant string
        return r.toString();
    }
}
