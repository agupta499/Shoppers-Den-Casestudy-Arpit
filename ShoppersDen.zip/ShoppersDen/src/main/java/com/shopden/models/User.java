package com.shopden.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class User {
    private int userId;
    private String userName;
    private String email;
    private String password;
    private String secQue;
    private String answer;
    private String address;
    private long phone;
    private UserRole userRole;
    private Cart cart;
}
