package com.shopden.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class CartProducts {
    private Cart cart;
    private Product product;
    private LocalDate dateAdded;
    private int quantity;
}
