package com.shopden.models;

public enum UserRole {
    ADMIN,CUSTOMER
}
