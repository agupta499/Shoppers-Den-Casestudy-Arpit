package com.shopden.models;

public enum PaymentMode {
    DEBIT,CREDIT,UPI,COD
}
